﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTrackingForm
{
    public class Data
    {
        public int MachineId { get; set; }
        public double Data1 { get; set; }
        public double Data2 { get; set; }
        public double Data3 { get; set; }
        public double Data4 { get; set; }
        public double Data5 { get; set; }
        public double Data6 { get; set; }
        public double Data7 { get; set; }
        public double Data8 { get; set; }
        public double Data9 { get; set; }
        public double Data10 { get; set; }
        public double Data11 { get; set; }
        public double Data12 { get; set; }
    }
}
